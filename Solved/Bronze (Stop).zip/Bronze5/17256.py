a, b, c = map(int, input().split())
d, e, f = map(int, input().split())
print(d-c, e//b, f-a)