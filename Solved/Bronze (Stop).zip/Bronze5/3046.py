r1, s = map(int, input().split())
print(2*s - r1)