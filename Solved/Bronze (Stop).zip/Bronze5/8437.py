a = int(input())
b = int(input())

print((a+b)//2)
print((a-b)//2)