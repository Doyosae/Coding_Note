result = []
for i in range(5):
    result.append(int(input()))

print(sum(result))