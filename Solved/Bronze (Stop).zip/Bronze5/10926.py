a = input()
print(a + "??!")