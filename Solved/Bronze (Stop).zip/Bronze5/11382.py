a, b, c = map(int, input().split())
print(sum([a, b, c]))