dist = int(input())

if dist%5 == 0:
    print(dist//5)
else:
    print((dist//5) + 1)