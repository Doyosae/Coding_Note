a = int(input())
print(4*a)