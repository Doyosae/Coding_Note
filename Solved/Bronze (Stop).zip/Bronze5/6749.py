a = int(input())
b = int(input())
print(b + (b-a))