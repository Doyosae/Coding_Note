a = int(input())
print(a - int(0.22*a))
print(a - int((0.22 * 0.2 * a)))