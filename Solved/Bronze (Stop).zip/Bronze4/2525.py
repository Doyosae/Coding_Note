a, b = map(int, input().split())
c    = int(input())

if b + c >= 60:
    m = (b+c) // 60
    n = (b+c) % 60
    a = a + m
    if a>=24:
        a = a % 24
        print(a, n)
    else:
        print(a, n)
else:
    print(a, b+c)