hour, minu, seco = map(int, input().split())
c                = int(input())

if seco + c >= 60:
    m1 = (seco+c) // 60
    m2 = (seco+c) % 60
    minu = minu + m1

    if minu >= 60:
        h1 = minu // 60
        h2 = minu % 60
        hour = hour + h1

        if hour >= 24:
            hour = hour % 24
            print(hour, h2, m2)
        else:
            print(hour, h2, m2)
    else:
        print(hour, minu, m2)
else:
    print(hour, minu, seco + c)