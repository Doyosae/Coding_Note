number = int(input())

if number % 2 == 1:
    result = number // 2
    result = (result+1) * (result + 2)
    print(result)
elif number % 2 == 0:
    result = number // 2
    result = (result+1) * (result+1)
    print(result)