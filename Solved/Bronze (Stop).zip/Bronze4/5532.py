L = int(input())
A = int(input())
B = int(input())
C = int(input())
D = int(input())

a = A//C
b = B//D

c = max([a, b])
if a == c:
    if A%C == 0:
        print(L-c)
    else:
        print(L-c-1)
elif b == c:
    if B%C == 0:
        print(L-c)
    else:
        print(L-c-1)