a = int(input())
b = list(input())

m1 = a * int(b[2])
m2 = a * int(b[1])
m3 = a * int(b[0])
print(m1)
print(m2)
print(m3)
m1 = m1
m2 = 10 * m2
m3 = 100 * m3

print(m1 + m2 + m3)