x, y = map(int, input().split())

if (x+y) % 2 == 0 and (x-y) % 2 == 0:
    if x < y:
        print(-1)
    else:
        print((x+y)//2, (x-y)//2)
else:
    print(-1)